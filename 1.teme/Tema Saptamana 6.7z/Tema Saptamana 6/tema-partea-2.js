// We need a program which calculates the Maximum Weight which a bed supports

// Bed Sizes
var bedSizeSmall = 20;
var bedSizeMedium = 30;
var bedSizeLarge = 40;

// Bed Structures
var bedStructureWeak = 100;
var bedStructureMedium = 125;
var bedStructureStrong = 150;

// Bed Material Types
var bedMaterialWood = 35.5;
var bedMaterialSteel = 70;
var bedMaterialConcrete = 100;

// Current bed data
var currentBedSize = bedSizeSmall;

// All variables are defined. We need to calculate the Max Allowed Weight for All Bed Material Types

if (currentBedSize === bedSizeSmall) {
	var maxAllowedWeightWood = bedSizeSmall * (bedStructureWeak / 2) * Math.pow(bedMaterialWood, 2);

	console.log("Bed size: " + bedSizeSmall + " -> Structure: " + bedStructureWeak + " -> Allowed weight: " + maxAllowedWeightWood);

	var maxAllowedWeightSteel = bedSizeSmall * (bedStructureMedium / 2) * Math.pow(bedMaterialSteel, 2);

	console.log("Bed size: " + bedSizeSmall + " -> Structure: " + bedStructureMedium + ". Allowed weight: " + maxAllowedWeightSteel);

	var maxAllowedWeightConcrete = bedSizeSmall * (bedStructureStrong / 2) * Math.pow(bedMaterialConcrete, 2);

	console.log("Bed size: " + bedSizeSmall + " -> Structure: " + bedStructureStrong + ". Allowed weight: " + maxAllowedWeightConcrete);

} else if (currentBedSize === bedSizeMedium) {
	var maxAllowedWeightWood = bedSizeMedium * (bedStructureWeak / 2) * Math.pow(bedMaterialWood, 2);

	console.log("Bed size: " + bedSizeMedium + " -> Structure: " + bedStructureWeak + " -> Allowed weight: " + maxAllowedWeightWood);

	var maxAllowedWeightSteel = bedSizeMedium * (bedStructureMedium / 2) * Math.pow(bedMaterialSteel, 2);

	console.log("Bed size: " + bedSizeMedium + " -> Structure: " + bedStructureMedium + ". Allowed weight: " + maxAllowedWeightSteel);

	var maxAllowedWeightConcrete = bedSizeMedium * (bedStructureStrong / 2) * Math.pow(bedMaterialConcrete, 2);

	console.log("Bed size: " + bedSizeMedium + " -> Structure: " + bedStructureStrong + ". Allowed weight: " + maxAllowedWeightConcrete);

} else if (currentBedSize === bedSizeLarge) {
	var maxAllowedWeightWood = bedSizeLarge * (bedStructureWeak / 2) * Math.pow(bedMaterialWood, 2);

	console.log("Bed size: " + bedSizeLarge + " -> Structure: " + bedStructureWeak + " -> Allowed weight: " + maxAllowedWeightWood);

	var maxAllowedWeightSteel = bedSizeLarge * (bedStructureMedium / 2) * Math.pow(bedMaterialSteel, 2);

	console.log("Bed size: " + bedSizeLarge + " -> Structure: " + bedStructureMedium + ". Allowed weight: " + maxAllowedWeightSteel);

	var maxAllowedWeightConcrete = bedSizeLarge * (bedStructureStrong / 2) * Math.pow(bedMaterialConcrete, 2);

	console.log("Bed size: " + bedSizeLarge + " -> Structure: " + bedStructureStrong + ". Allowed weight: " + maxAllowedWeightConcrete);
}
